#include<stdio.h>
#include<string.h>
void main()
{
	int x= 6;
	int a[6]={1,2,3,4,5,6};
	int m = 0;
	int n = 5;
	int h = 0;
	while(m <= n){
		printf("*\n");
		h = (m + n ) / 2;     //h = 4
		if(a[h] > x)
			n = h - 1;
		else if(a[h] < x)
			m = h + 1;
		else
		{
			printf("%d",h);
			break;
		}
	}
}
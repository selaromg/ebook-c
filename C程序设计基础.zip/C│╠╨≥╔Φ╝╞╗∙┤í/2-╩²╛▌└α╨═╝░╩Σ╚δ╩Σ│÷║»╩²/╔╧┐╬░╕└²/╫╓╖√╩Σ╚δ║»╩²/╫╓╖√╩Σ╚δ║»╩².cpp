#include <stdio.h>
int main() 
{ 
	char a1 = 'w';
	char a2 = 'e';
	char a3 = 'l';
	char a4 = 'c';
	char a5 = 'o';
	char a6 = 'm';
	char a7 = 'e';

	printf("%c\n",a1 + 2 );
	printf("\t%c\n",a2 + 2);
	printf("\t\t%c\n",a3 + 2);
	printf("\t\t\t%c\n",a4 + 2);
	printf("\t\t\t\t%c\n",a5 + 2);
	printf("\t\t\t\t\t%c\n",a6 + 2);
	printf("\t\t\t\t\t\t%c\n",a7 + 2);
} 

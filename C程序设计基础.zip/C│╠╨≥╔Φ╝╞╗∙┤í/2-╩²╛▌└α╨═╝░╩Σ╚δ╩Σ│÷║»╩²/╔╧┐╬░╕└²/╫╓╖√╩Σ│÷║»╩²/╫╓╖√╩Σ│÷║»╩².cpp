#include <stdio.h>
int main() 
{ 
	char sex = 'f';
	printf("�Ա�:");
	//scanf("%c",&sex);
	sex = getchar();
	//printf("sex = %c",sex);
	printf("sex = ");
	putchar(sex);
} 

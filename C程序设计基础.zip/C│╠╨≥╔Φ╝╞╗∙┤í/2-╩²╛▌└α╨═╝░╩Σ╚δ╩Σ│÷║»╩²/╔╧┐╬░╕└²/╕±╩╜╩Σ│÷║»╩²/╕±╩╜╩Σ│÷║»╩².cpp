#include <stdio.h>
int main() 
{ 
	int a = 1234; 
	float f = 3.141592653589; 
	printf("a = %d\n",a);      
	printf("a = %-6d\n",a); 
	printf("a = %-06d\n",a); 
	printf("a = %2d\n",a);     
	printf("f = %f\n",f);        
	printf("f = %6.4f\n",f); 
} 

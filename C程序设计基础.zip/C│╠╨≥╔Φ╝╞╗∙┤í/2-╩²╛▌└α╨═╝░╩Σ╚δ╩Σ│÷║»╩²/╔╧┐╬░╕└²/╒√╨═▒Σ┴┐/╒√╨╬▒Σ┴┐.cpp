// DefineTest.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include <stdio.h>
#define pi 3.14
void main()
{
	int a1 = 1;
	int a2 = 2;
	int a3 = 3;
	int a4 = 4;
	int a5 = 5;
	int a6 = 6;
	int a7 = 7;
	int a8 = 8;
	int a9 = 9;
	int a10 = 10;
	int sum = a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10;
	printf("%d + %d + %d + %d + %d + %d + %d + %d + %d + %d = %d",a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,sum);


}
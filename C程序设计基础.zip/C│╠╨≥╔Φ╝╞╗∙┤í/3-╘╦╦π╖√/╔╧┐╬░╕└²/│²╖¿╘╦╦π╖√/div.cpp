#include <stdio.h>
void main()
{
	int a = 20;
	int b = 7;

	printf("%d\n",a / b );

	float af = 20.0f;
	int bf = 7;

	printf("%f",af / bf );

}

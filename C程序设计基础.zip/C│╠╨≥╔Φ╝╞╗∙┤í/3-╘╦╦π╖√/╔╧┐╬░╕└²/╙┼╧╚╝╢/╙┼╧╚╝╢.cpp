#include <stdio.h>
void main()
{
	int a = 3;
	int b = 1;

	int c = -a++ + b;
	printf("c=%d,a=%d",c,a);
}
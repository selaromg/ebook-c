#include <stdio.h>
void main()
{
	int a = 20;
	int b = 7;

	a = a + 1;
	b++;

	--a;
	--b;

	printf("%d,%d\n",a,b );
}

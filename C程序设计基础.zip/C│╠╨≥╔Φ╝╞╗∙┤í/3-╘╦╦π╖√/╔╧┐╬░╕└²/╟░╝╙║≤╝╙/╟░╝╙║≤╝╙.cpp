#include <stdio.h>
void main()
{
	int a = 20;
	int b = 7;

	a++;
	++a;

	printf("%d,%d\n",a++,b );
	printf("%d,%d\n",++a,b );
}
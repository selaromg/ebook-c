#include <stdio.h>
void main()
{
	int a[6]={1,8,4,9,3,6};
	int max = a[0];
	for(int i = 1;i<6;i++)
		max = max > a[i]?max:a[i];

	printf("%d",max);
	
}

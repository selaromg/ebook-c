
/*
* ���������㷨
*/
#include<stdio.h>
void main()
{
	int  temp,num;
	int a[10000] = {1,3,8,11,17,24}; // n=6
	int count = 6;
	printf("��������Ҫ�������");
	scanf("%d",&num);
    
   	   for(int i=0;i<count;i++)
	   {
		   if(num<=a[i])
		   {
               for(int j=count;j>i;j--)
			   {
                  a[j] = a[j-1];
			   }
			   a[i] = num;
			   count++;
			   break;
		   }
	   }
	   for(int i=0;i<count;i++)
	   {
		   printf("%d ",a[i]);
	   }
}
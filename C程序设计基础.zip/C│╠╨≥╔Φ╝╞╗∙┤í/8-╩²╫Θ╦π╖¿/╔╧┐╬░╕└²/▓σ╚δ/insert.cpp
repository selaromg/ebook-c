#include <stdio.h>
void main()
{
	int arr[15]={1,2,4,7};
	int count = 4;
	int value = 8;
	int i = 0;

	int findIndex = 0;
	
	for(i = 0;i<count;i++)
	{
		if(value < arr[i]){
			findIndex = i;
			break;
		}
	}
	if(i == count)
		arr[i] = value;
	else 
	{
		for(i = 4;i > findIndex;i--)
			arr[i] = arr[i-1];
		arr[findIndex] = value;
	}
	count++;

	for(i = 0;i<count;i++)
		printf("%d\t",arr[i]);
}

#include <stdio.h>
void main()
{
	int a[8] = {1,9,12,27,36,50};
	int count = 6;
	int value = 280;
	int index = 0;
	int i = 0;
	for(;i<count;i++)
		if(a[i] > value)
		{
			index = i;
			break;
		}
	if(i == count)
		index = i;

	for(int i = count -1;i>=index;i--)
		a[i + 1] = a[i];
	a[index] = value;
	count++;


	for(int i = 0;i<count;i++)
		printf("%d\t",a[i]);
}

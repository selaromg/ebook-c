
/*
* ɾ�������㷨
*/
#include<stdio.h>
void main()
{
	int  temp,num;
	int a[10000] = {1,3,8,11,17,24}; // n=6
	int count = 6;
	printf("��������Ҫɾ������");
	scanf("%d",&num);
    
   	   for(int i=0;i<count;i++)
	   {
		   if(num==a[i])
		   {
               for(int j=i;j<count;j++)
			   {
                  a[j] = a[j+1];
			   }
			   count--;
			   break;
		   }
	   }
	   for(int i=0;i<count;i++)
	   {
		   printf("%d ",a[i]);
	   }
}
/* 
      4, 1, 5, 3, 6, 2
	    1,4,3,5,2,6
		1,3,4,2,5,6
		1,3,2,4,5,6
		1,2,3,4,5,6


   ð����������㷨
	  
*/
#include<stdio.h>
void main()
{
	int  temp;
	int a[6] = {8,1,3,12,22,17}; 
	 for(int i=0;i<5;i++)
	   {
		   for(int j=0;j<5-i;j++)
		   {
              if(a[j] > a[j+1])
			  {
				  temp =a[j];
				  a[j] = a[j+1];
				  a[j+1]=temp;
			  }
		   }
	   }
	   for(int i=0;i<6;i++)
	   {
		   printf("%d ",a[i]);
	   }
}

/*
* ѡ�������㷨
*/
#include<stdio.h>
void main()
{
	int  temp;
	int a[6] = {8,1,3,12,22,17}; // n=6
	   for(int i=0;i<5;i++)
   {
	   for(int j=i+1;j<6;j++)
	   {
		   if(a[i]>a[j])
		   {
			   temp=a[i];
			   a[i]=a[j];
			   a[j] = temp;
		   }
	   }
   }
	   for(int i=0;i<6;i++)
	   {
		   printf("%d ",a[i]);
	   }
}
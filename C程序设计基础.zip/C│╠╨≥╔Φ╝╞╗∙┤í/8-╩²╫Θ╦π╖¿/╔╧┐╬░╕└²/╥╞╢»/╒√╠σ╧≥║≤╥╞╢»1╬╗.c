/*
��������ƶ�1λ
*/
#include<stdio.h>
void main()
{
	int  temp,count=6;
	int a[10] = {1,3,8,12,22,17}; 

	 for(int i=count;i>=1;i--)
	 {
		a[i]=a[i-1];
	 }
	 a[0]=0;
	 for(int i=0;i<7;i++)
	 {
	   printf("%d ",a[i]);
	 }
}


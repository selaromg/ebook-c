/*
����ƶ�1λ,ѭ��
*/
#include<stdio.h>
void main()
{
	int  temp;
	int a[10] = {1,3,8,12,22,17}; 
	 for(int i=0;i<6;i++)
	 {
		temp = a[i];
		a[i]= a[5];
		a[5] = temp;
	 }
	   for(int i=0;i<6;i++)
	   {
		   printf("%d ",a[i]);
	   }
}


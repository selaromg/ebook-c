#include <stdio.h>
void main()
{
	int a[6] = {1,9,120,27,36,50};
	for(int i = 1;i<6;i++)
		for(int j = 0;j<i;j++)
		{
			if(a[j] > a[i])
			{
				int temp = a[i];
				for(int k = i-1;k>=j;k--)
					a[k + 1] = a[k];
				a[j] = temp;
			}
		}


	for(int i = 0;i<6;i++)
		printf("%d\t",a[i]);
}
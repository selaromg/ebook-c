#include<stdio.h>
void main()
{
	int i;
	char num[8];
	int a;
	int sum1=1;
	int sum2=0;
	int h;
	printf("������һ��������");
	for(a=0;a<8;a++)
	{
	scanf("%c",&num[a]);
	if(num[a]=='\n')
		break;
	}
	int c=0;
	for( c=0;c<a;c++)
	{
		printf("%c",num[c]);
	    i=c+1;
		h=i;
	}
	printf("\n%d\n",i);
	for(int d=0;d<i;d++,h--)
	{
		sum1=1;
		for(int e=h-1;e>0;e--)
		{
		/*	switch(num[d])
			{
			case'1':sum1=2*sum1;
				break;
			case'0':sum1=0*2;
				break;*/
			}
		}
		sum2=sum1+sum2;
		
		
			
	}
	printf("%d",sum2);

}


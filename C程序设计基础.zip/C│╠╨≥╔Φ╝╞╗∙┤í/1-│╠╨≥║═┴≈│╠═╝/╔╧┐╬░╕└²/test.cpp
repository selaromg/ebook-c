#include<stdio.h>

void main()
{
	int r ;
	r =12 ;
	float p=3.14f;
	float area = r*r*rp ;
	printf(" %d : \n",area);
}
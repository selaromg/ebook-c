struct Student
{
	int id;
	char name[20];
	float score[2];
	float avg;
};
struct Student input();
void show(struct Student);
int getMenu();
void sort(struct Student[],int);
void query(struct Student[] ,int );
void update(struct Student[],int);
void remove(struct Student[],int*);
int allinput(struct Student[],int);
void display(struct Student[],int);
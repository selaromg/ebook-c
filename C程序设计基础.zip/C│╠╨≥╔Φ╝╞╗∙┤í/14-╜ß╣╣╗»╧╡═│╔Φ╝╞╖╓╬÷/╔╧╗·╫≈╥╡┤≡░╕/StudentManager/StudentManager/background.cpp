#include<stdio.h>
#include "backgroudhead.h"
struct Student input()
{
	struct Student student;
	printf("\nѧ��:");
	scanf("%d",&student.id);
	fflush(stdin);
	printf("\n����:");
	gets(student.name);
	float sum = 0.0f;
	printf("\n���ųɼ�:\n");
	for(int i = 0;i<2;i++)
	{
		scanf("%f",&student.score[i]);
		sum += student.score[i];
	}
	student.avg = sum / 2;
	return student;
}
void show(struct Student student)
{
	printf("%-3d\t",student.id);
	printf("%-20s\t",student.name);
	printf("%5.1f",student.score[0]);
	printf("%5.1f\t",student.score[1]);
	printf("%5.1f\t",student.avg);
	printf("\n");
}
void sort(struct Student student[],int count)
{
	for(int i = 0;i<count-1;i++)
		for(int j = i+1;j<count;j++)
			if(student[i].avg < student[j].avg)
			{
				struct Student temp = student[i];
				student[i] = student[j];
				student[j] =  temp;
			}
}
int getMenu()
{
	printf("ѧ���ɼ�����ϵͳ");
	printf("\n1.¼��");
	printf("\n2.��ʾ");
	printf("\n3.����");
	printf("\n4.��ѯ");
	printf("\n5.�޸�");
	printf("\n6.ɾ��");
	printf("\n7.�˳�");
	printf("\n��ѡ��:");
	int select = 0;
	scanf("%d",&select);
	return select;
}
int find(struct Student students[],int count,int no)
{
	for(int i =0;i<count;i++)
		if(no == students[i].id)
			return i;
	return -1;
}
void query(struct Student students[],int count)
{
	printf("\n������ѧ��:");
	int id = 0;
	scanf("%d",&id);
	int index = find(students,count,id);
	if(index==-1)
	{
		printf("\n�޴�ѧ��!");
	}else
	{
		show(students[index]);
	}
}

void update(struct Student students[],int count)
{
	printf("\n������ѧ��:");
	int id = 0;
	scanf("%d",&id);
	int index = find(students,count,id);
	if(index==-1)
	{
		printf("\n�޴�ѧ��!");
	}else
	{
		students[index] = input();
	}
}

void remove(struct Student students[],int* count)
{
	printf("\n������ѧ��:");
	int id = 0;
	scanf("%d",&id);
	int index = find(students,*count,id);
	if(index==-1)
	{
		printf("\n�޴�ѧ��!");
	}else
	{
		//ɾ��
		for(int i = index + 1;i<*count;i++)
			students[i-1] = students[i];
		(*count)--;
	}
}

int allinput(struct Student students[],int count)
{
	char flag = 'y';
	while(flag == 'y')
	{
		students[count++] = input();
		printf("��������?(y or n):");
		fflush(stdin);
		flag = getchar();
	}
	return count;
}
void display(struct Student students[],int count)
{
	for(int i = 0;i<count;i++)
			{
				show(students[i]);
			}
}
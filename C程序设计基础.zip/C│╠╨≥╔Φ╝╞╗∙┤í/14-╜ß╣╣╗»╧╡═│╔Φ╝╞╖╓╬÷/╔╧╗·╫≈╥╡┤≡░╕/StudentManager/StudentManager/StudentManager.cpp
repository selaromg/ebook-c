// StudentManager.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include<stdio.h>
#include<stdlib.h>
#include"backgroudhead.h"
void main()
{
	struct Student student[2000];
	int count = 0;

	while(1)
	{
		int select = getMenu();
		if(select == 1)
		{
			count = allinput(student,count);
			system("cls");
		}else if(select ==2)
		{
			system("cls");
			display(student,count);
			printf("�������,�������˵�.......");
			fflush(stdin);
			getchar();
			system("cls");
		}else if(select == 3)
		{
			sort(student,count);
		}else if(select == 4)
		{
			query(student,count);
		}else if(select == 5)
		{
			update(student,count);
		}else if(select == 6)
		{
			remove(student,&count);
		}else if(select == 7)
		{
			break;
		}
	}
}

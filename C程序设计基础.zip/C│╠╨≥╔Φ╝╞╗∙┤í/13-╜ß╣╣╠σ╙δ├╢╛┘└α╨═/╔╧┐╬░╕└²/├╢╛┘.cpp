#include <stdio.h>

struct date
{
	int year;
	int month;
	int day;
};

enum sex {F,M};

struct person
{
	char id[19];
	char name[20];
	struct date birthday;
	enum sex personsex;
}

void main()
{
	struct person bill;
	bill.birthday.year = 2001;
	bill.personsex = F;
	bill.personsex = M;
}
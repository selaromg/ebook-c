#include <stdio.h>
void main()
{
	int a = 1;
	int sum = 0;


	while(a <= 1000)
	{
		sum += a;
		a++;
	}

	printf("%d",sum);
}

////////////////////////////////


#include <stdio.h>
void main()
{
	char ch = ' ' ;
	int xiao = 0;
	int da = 0;
	int kong = 0;
	int shu = 0;
	//scanf("%c",&ch);
	while((ch=getchar()) != '\n')
	{
		if(ch >= 'a' && ch <= 'z')
			xiao ++;
		else if(ch >= 'A' && ch <= 'Z')
			da ++;
		else if (ch >= '0' && ch <='9')
			shu ++;
		else if(ch == ' ' )
			kong ++;
		//scanf("%c",&ch);
	}
	printf("Сд������:%d",xiao);
	printf("��д������:%d",da);
	printf("���ֵ�����:%d",shu);
	printf("�ո������:%d",kong);


}



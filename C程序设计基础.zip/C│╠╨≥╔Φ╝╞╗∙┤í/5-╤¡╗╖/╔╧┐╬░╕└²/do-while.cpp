#include <stdio.h>
void main()
{
	int n = 0;
	int min = 0;
	scanf("%d",&n);
	min = n;
	do
	{
		if(min > n)
			min = n;	
		scanf("%d",&n);
	}while(n != 0);

	printf("\n%d",min);
}

#include <stdio.h>
#include <stdlib.h>

void main()
{
	
	do
	{
		int rnd = rand() % 6 + 1 ;
		int user = 0;
		printf("������:");
		scanf("%d",&user);
		if(user > rnd )
			printf("ok");
		else if (user == rnd)
			printf("oooook");
		else
			printf("ook");
	}while(getchar() != 'X');
}
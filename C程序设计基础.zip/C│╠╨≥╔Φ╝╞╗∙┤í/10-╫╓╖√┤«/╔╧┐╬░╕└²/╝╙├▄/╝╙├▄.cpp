#include<stdio.h>
#include<string.h>

void main()
{
	char psw[7];
	gets(psw);
	
	for(int i = 0;i<strlen(psw);i++)
		psw[i] = psw[i] + 3 > '9'? psw[i]  + 3 - 10:psw[i] + 3;

	puts(psw);
}
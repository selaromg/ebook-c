#include<stdio.h>
#include<string.h>

void main()
{
	char a[5][5] = {"bill","mary","tony","jack","alex"};
	char temp[5];
    for(int i=0;i<4;i++)
	{
		for(int j=i+1;j<5;j++)
		{
			if(strcmp(a[i],a[j])==1)
			{
                strcpy(temp,a[i]);
				strcpy(a[i],a[j]);
				strcpy(a[j],temp);
			}
		}
	}
	for(int i=0;i<5;i++)
	{
		puts(a[i]);
	}

}
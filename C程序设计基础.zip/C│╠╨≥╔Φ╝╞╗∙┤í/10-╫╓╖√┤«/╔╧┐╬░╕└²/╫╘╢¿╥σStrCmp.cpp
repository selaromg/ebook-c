#include<stdio.h>

int StrCmp(char s1[20],char s2[20])
{
	for(int i=0;i<20;i++)
	{
		if(s1[i] > s2[i])
			return 1;
		if(s1[i] <s2[i])
			return -1;
		if(s1[i] == '\0' && s2[i]!='\0')
			return -1;
		if(s1[i] !='\0' && s2[i] == '\0')
			return 1;
		if(s1[i]== s2[i])
			continue;
	}
	return 0;
}

void main()
{
   int res = StrCmp("StrCmp","alex");
   printf("%d ",res);
}
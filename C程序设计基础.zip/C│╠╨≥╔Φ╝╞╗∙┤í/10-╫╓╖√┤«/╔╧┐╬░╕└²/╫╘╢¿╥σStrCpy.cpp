#include<stdio.h>

int StrCpy(char s1[20],char s2[20])
{
	for(int i=0;i<20;i++)
	{
		s1[i] = s2[i];
	}
	return 1;
}

void main()
{
   char name[20];
   int res = StrCpy(name,"alex");
   printf("%s ",name);
}
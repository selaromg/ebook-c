#include<stdio.h>

int StrLen(char s[])
{
	int count=0;
	for(int i=0;s[i] != '\0';i++)
	{
		count++;
	}
	return count;
}

void main()
{
   int res = StrLen("alex");
   printf("%d ",res);
}
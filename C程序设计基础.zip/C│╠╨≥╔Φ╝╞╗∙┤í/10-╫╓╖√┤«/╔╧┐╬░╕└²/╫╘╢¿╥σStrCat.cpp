#include<stdio.h>

int StrCat(char s1[20],char s2[20])
{
    int count=0;
	for(int i=0;s1[i]!='\0';i++)
	{
      count++;
	}

	for(int i=count-1,j=0;i<20;i++,j++)
	{
		if(s2[j]=='\0')
			break;
		s1[i+1] = s2[j];
		
	}
	return 1;
}

void main()
{
   char name[20]="Bill";
   int res = StrCat(name,"alex");
   printf("%s ",name);
}